# -*- coding: utf-8 -*-
import sys
import random
import time
import matplotlib
matplotlib.use("Qt5Agg")
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QApplication, QMainWindow, QMenu, QVBoxLayout, QSizePolicy, QMessageBox, QWidget
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from numpy import arange
import pandas as pd
import ControlCanvas
from functools import partial

class Ui_MainWindow(object):	
	def setupUi(self, MainWindow):
		MainWindow.setObjectName("MainWindow")
		self.screen = QtWidgets.QDesktopWidget().screenGeometry()
		MainWindow.setGeometry(10, 50, self.screen.width()/4,self.screen.height()/4)
		# MainWindow.resize(self.screen.width()/4,self.screen.height()/4)
		# MainWindow.showMaximized()
		self.centralWidget = QtWidgets.QWidget(MainWindow)
		self.centralWidget.setObjectName("centralWidget")
		MainWindow.setCentralWidget(self.centralWidget)
####################################################################################
		#QGridLayout
		self.gridLayout = QtWidgets.QGridLayout(self.centralWidget)
		self.gridLayout.setSpacing(6)
		self.gridLayout.setObjectName("gridLayout")
		#
		# Canvas
		self.main_widget = QWidget()
		self.dc = ControlCanvas.MyControlMplCanvas(self.main_widget, width=5, height=4, dpi=100)
		self.gridLayout.addWidget(self.dc,0,2)
		#
		#QVBoxLayout
		self.verticallayout = QtWidgets.QVBoxLayout()
		# self.verticallayout.setContentsMargins(11, 11, 11, 11)
		self.verticallayout.setSpacing(6)
		self.verticallayout.setObjectName("verticallayout")
		self.gridLayout.addLayout(self.verticallayout, 0, 1)
		#
		self.lb = []
		self.hs = []
		self.sp = []
		self.echoGroup =  QtWidgets.QGroupBox('Echo')
		self.echoLayout = QtWidgets.QGridLayout()
		self.echoGroup.setLayout(self.echoLayout)
		sp_inital_value = [3.9e-3,1.91,1.49,0.0029,11.,0.064,1191.0,11.7]
		lb_name = ['K','C1','C2','C3','C4','m','alpha','a']
		for i in range(8):
			self.lb.append(i);self.hs.append(i);self.sp.append(i)
			self.lb[i] = QtWidgets.QLabel(lb_name[i])
			self.echoLayout.addWidget(self.lb[i],i+1,0)
			self.hs[i] = QtWidgets.QSlider(self.centralWidget)
			self.hs[i].setOrientation(QtCore.Qt.Horizontal)
			self.hs[i].setRange(-9999.,9999.)
			self.echoLayout.addWidget(self.hs[i],i+1,2)

			self.sp[i] = QtWidgets.QDoubleSpinBox()
			self.sp[i].setDecimals(4)
			# self.sp[i].valueFromText('0.2')
			self.sp[i].setValue(sp_inital_value[i])
			self.sp[i].setSingleStep(0.01*sp_inital_value[i]) 
			self.sp[i].setRange(-2*sp_inital_value[i],2*sp_inital_value[i])
			self.echoLayout.addWidget(self.sp[i],i+1,1)
			self.hs[i].valueChanged.connect(self.sp[i].setValue)
			self.sp[i].valueChanged.connect(self.hs[i].setValue)
			self.hs[i].sliderReleased.connect(lambda: self.dc.update_figure(pars=self.DSGZ_args()))
			self.sp[i].valueChanged.connect(lambda: self.dc.update_figure(pars=self.DSGZ_args()))
		self.gridLayout.addWidget(self.echoGroup,0,0)
		#
		
		##QFileDir
		self.btn2 = QtWidgets.QPushButton("打开目标文件")
		self.echoLayout.addWidget(self.btn2,0,0)
		self.btn2.clicked.connect(self.filedirgetfile)
		#
	def filedirgetfile(self):
		self.filedir,_ = QtWidgets.QFileDialog.getOpenFileName(caption='Open',directory="D:\\",filter="CSV files(*.txt *.csv)")
		self.testing = pd.read_csv(self.filedir)
		print (self.filedir)
		return self.testing
	#
	def DSGZ_args(self):
		self.DSGZ_Args = [self.sp[i].value() for i in range(8)]
		print (self.DSGZ_Args)
		# self.dc.update_figure(self.DSGZ_Args)
		return self.DSGZ_Args,self.testing
####################################################################################
if __name__ == "__main__":
	app = QtWidgets.QApplication(sys.argv)
	ex = Ui_MainWindow()
	w = QtWidgets.QMainWindow()
	ex.setupUi(w)
	w.show()
	sys.exit(app.exec_())
####################################################################################