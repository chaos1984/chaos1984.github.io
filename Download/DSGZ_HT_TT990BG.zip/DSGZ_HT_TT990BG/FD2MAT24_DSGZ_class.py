# -*- coding: utf-8 -*-
"""
Author:Yujin.Wang
Date:2019.04.07
The lib. is used to translate the F-D curve to MAT24 effective plastic strain - true stress.
Usage:
MAT89LCSS(fdfile,A,l0) 
return TrueStrain,TrueStress,[PeakStrain,PeakStress]
MAT24LCSS(truestrain,truestress,yieldpoint=0.02,Ymould_user=0,Peak=[0,0],strainturn=0,scaleturn=1,curvescale=1,ratio=1,extend=0,scaleextend=0,alignstrain=1.45,pointnum=50):
return x_strain_mod,y_strain_mod
CurveKey(A,l0,FDfile,strain_rate,curvenum,ratio,Ymould_user,yieldpoint,pointnum,strainturnlist,scaleturnlist,curvescalelist,alignstrain,extend,scaleextend):
No return
################################################################################
Parameters:
    A - float, Specemen Crosssection area
	l0 - float, Gage lengrh
    FDfile - Filename, Force-Disp curve
    strain_rate - list, Strain rate
    curvenum - int, Curve number in .key file
    ratio - float, Display ratio
#################################User Define###################################
    Ymould_user - float, Young modulus
    yieldpoint - float, Yield point
    pointnum - int, the number of output points
    strainturnlist - list, Turn strain 
    scaleturnlist - list,  Scale of the turn strain 
    curvescalelist - list, Curve scale equalent to SFO
    alignstrain - float, align the strain to user defined value(>max(strainturnlist))
    extend - float, Extend strain to a user defined value
    scaleextend - float, Scale of the extend strain 
"""
import time
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import interpolate,optimize
import scipy.signal as signal
from sympy import symbols,nsolve

def f_strain(strain,c1,c2,a):
    return (np.power(np.e,-c1*strain) + np.power(strain,c2))*(1-np.power(np.e,-a*strain))

def h_strainrate_T(strainrate,m,T,alpha):
    return np.power(strainrate,m)*np.power(np.e,alpha/T)

def DGSZ(strain,strainrate,T,K,c1,c2,c3,c4,a,m,alpha):
    f = f_strain(strain,c1,c2,a)
    h = h_strainrate_T(strainrate,m,T,alpha)
    value = K * ( f + (strain*np.power(np.e,(1.-strain/(c3*h)))/(c3*h)-f) * np.power(np.e,(np.log(h)-c4)*strain))*h
#    print (strain*np.power(np.e,(1-strain/(c3*h)))/(c3*h)-f)
    return value


def DGSZ_c1c2(strain,stress):
    c1,c2 = symbols('c1,c2')
    equations = [(np.power(np.e,-c1*strain[0]) + np.power(strain[0],c2))     \
                 /(np.power(np.e,-c1*strain[1]) + np.power(strain[1],c2)) - stress[0]/stress[1], \
                 (np.power(np.e,-c1*strain[0]) + np.power(strain[0],c2))     \
                 /(np.power(np.e,-c1*strain[1]) + np.power(strain[2],c2)) - stress[0]/stress[2]]
    result = nsolve(equations,[c1,c2],[0,0],verify=False)
    return result
    
def DGSZ_m(strainrate,stress):
    return np.log(stress[0]/stress[1]) / np.log(strainrate[0]/strainrate[1])

def DGSZ_alpha(T,stress):
    return np.log(stress[0]/stress[1])/(1./T[0]-1/T[1])

def DGSZ_K(stress,strain,strainrate,m,T,alpha,c1,c2):
    h = h_strainrate_T(strainrate,m,T,alpha)
    return stress/(h*np.power(np.e,-c1*strain)+np.power(strain,-c2))

def DGSZ_c3(strain,strainrate,m,T,alpha):
    h = h_strainrate_T(strainrate,m,T,alpha)
    return strain/h
    
def DGSZ_c4(strainrate,m,alpha,T):
    return 200. + np.log(np.power(strainrate,m)*np.power(np.e,alpha/T))

def DSGZ_a(strain):
    return -np.log(0.03)/strain

def CowperSymondsFunc(x,c,p):
    rate,ES0 = x
    return ES0*(1+np.power((rate/c),1./p))

def ConditionRemove(data,condition):
    a =[]
    isflag = 1
    string ="if "+ condition +":\n"
    string +="                     for k in range(len(data)):\n   \
                        data[k].pop(i+1)\n   \
                  isflag = 1\n"
    while isflag == 1:
        a.extend(data)
        len0 = len(a[0])
        try:
            for i in range(len(a[0])):
                exec(string)
        except:
            if len(data[0]) == len0:
                break
    return data
    
    
def MAT89LCSS(fdfile,A,l0):
    '''fdfile -- Force-Displacement Curve
       A -- Area of the Cross section of specimen
       l -- Length of the specimen (gage length or grip length or equalent length)
       Output : TrueStrain,TrueStress,[PeakStrain,PeakStress]
     '''
    data = pd.read_csv(fdfile)
    x = data.Disp
    y = data.Force
    EngStrain = x/l0
    EngStress = y/A
    EngStressFilt =  pd.Series(signal.medfilt(EngStress,201))
    PeakStress = max(EngStressFilt[:800])
    PeakStrain = EngStrain[EngStressFilt[:800].idxmax()]
    print "PeakStress:%f\tPeakStrain:%f\t Elastic modulus:%f" %(PeakStress,PeakStrain,PeakStress/PeakStrain)
    plt.figure(1)
    plt.grid("on")
    plt.scatter(PeakStrain,PeakStress, marker='o')
    plt.title("Engineering Strain VS. Engineering Stress Curve")
    plt.xlabel("Engineering Strain[-]")
    plt.ylabel("Engineering Stress[GPa]")
#    plt.xticks([])
#    plt.yticks([])
#    plt.plot(PeakStrain,PeakStress,'p')
    plt.plot(EngStrain,EngStressFilt)
#    plt.plot(EngStrain,EngStressFilt,'--')
    plt.legend(["0.01mm/ms","0.1mm/ms","1mm/ms","10mm/ms"])
    TrueStrain =  np.log(1+EngStrain)
    TrueStress = EngStressFilt*(1+EngStrain)
    plt.figure(2)
#    plt.plot(EngStrain,EngStress,'b')
    plt.grid("on")
    plt.title("True Strain VS. True Stress Curve")
#    plt.xticks([])
#    plt.yticks([])
    plt.xlabel("True Strain[-]")
    plt.ylabel("True Stress[GPa]")
    plt.plot(TrueStrain,TrueStress)
    plt.legend(["0.01mm/ms","0.1mm/ms","1mm/ms","10mm/ms"])
    return TrueStrain,TrueStress,[PeakStrain,PeakStress]

def MAT24LCSS(x,y,yieldpoint=0.02,Ymould_user=0,Peak=[0,0],strainturn=0,scaleturn=1,curvescale=1,ratio=1,extend=0,scaleextend=0,alignstrain=1.45,pointnum=50,smoothflag=0):
    '''Input:
        TrueStrain,TrueStressm
        Output:Modiifed Eff. Stress Vs. Eff. plastic strain
    '''
    y_strain = []
    x_strain = []
    for index,value in enumerate(x):
        if value >= yieldpoint and (value > x[index-1] or y[index]>y[index-1]):
            x_strain.append(value - y[index]/Ymould_user)
            y_strain.append(y[index])
    plt.figure(4)
    displayratio = int(len(x_strain)*ratio)
#    plt.plot(x_strain[:displayratio],y_strain[:displayratio],'--')
    x_strain_mod =[0] 
    y_strain_mod = [y_strain[0]/3.]
    delta = int(len(x_strain)/pointnum)
    x_strain_mod.extend( [value for index,value in enumerate(x_strain) if index%delta==0]);y_strain_mod.extend([value for index,value in enumerate(y_strain) if index%delta==0])
    for index,value in enumerate(x_strain_mod):
        if value > strainturn:
            y_strain_mod[index]= y_strain_mod[index-1]+scaleturn*(x_strain_mod[index]-x_strain_mod[index-1])
        else:
            continue
    if x_strain_mod[-1] < alignstrain:
        x_strain_mod.append(alignstrain)
        y_strain_mod.append(y_strain_mod[-1]+scaleturn*(x_strain_mod[-1]-x_strain_mod[-2]))
    for index,value in enumerate(x_strain_mod):
        y_strain_mod[index] = y_strain_mod[index]*curvescale
    if extend != 0:
        x_strain_mod.append(x_strain_mod[-1]+extend)
        y_strain_mod.append(y_strain_mod[-1]+extend*(scaleextend))
        plt.title("Modified Effective Plastic Strain VS. Stress Curve")
    plt.xlabel("Effective Plastic Strain[-]")
    plt.ylabel("Stress[GPa]")
    plt.grid('on')
    if smoothflag == 1:
        print "The curve has been smoothed!"
        f = interpolate.interp1d(x_strain_mod,y_strain_mod,kind='cubic')
        x_strain_smooth = np.linspace(x_strain_mod[0],x_strain_mod[-1],pointnum)
        y_strain_smooth = f(x_strain_smooth)
        plt.plot(x_strain_smooth[:displayratio],y_strain_smooth[:displayratio])
#        plt.legend(["Strain Rate 0.001/ms","Modified Strain Rate 0.001/ms","Strain Rate 0.01/ms","Modified  Strain Rate 0.01/ms","Strain Rate 0.1/ms","Modified Strain Rate 0.1/ms","Strain Rate 1/ms","Modified Strain Rate 1/ms",])
        return x_strain_smooth,y_strain_smooth
    elif smoothflag == 0:
        plt.plot(x_strain_mod[:displayratio],y_strain_mod[:displayratio])
#        plt.legend(["Strain Rate 0.001/ms","Modified Strain Rate 0.001/ms","Strain Rate 0.01/ms","Modified  Strain Rate 0.01/ms","Strain Rate 0.1/ms","Modified Strain Rate 0.1/ms","Strain Rate 1/ms","Modified Strain Rate 1/ms",])
        return x_strain_mod,y_strain_mod

def CurveKey(A,l0,FDfile,strain_rate,curvenum,ratio,Ymould_user,yieldpoint,pointnum,strainturnlist,scaleturnlist,curvescalelist,alignstrain,extend,scaleextend,smooth=0):
    fout = open("Curve.key",'w')
    fout.write('*KEYWORD\n')
    fout.write('$ Created: ' + time.strftime("%d.%m.%Y %H:%M:%S") + '\n')
    fout.write('$ Parameters:\n$ A:%f\n$ l0:%f\n$ Young modulus:%f\n$ Yield point:%f\n$ Alignstrain:%f\n$ Extend strain:%f\n$ Scaleextend:%f\n' %(A,l0,Ymould_user,yieldpoint,alignstrain,extend,scaleextend))
    fout.write("$ Control List:\n$ Strain turning:%s\n$ Strain scaleturn:%s\n$ Curvescale:%s\n" %(str(strainturnlist),str(scaleturnlist),str(curvescalelist)))
    fout.write("*DEFINE_TABLE\n%d\n" %(curvenum))
    for i in strain_rate:
        fout.write("%f\n" %(i))    
    for index,File in enumerate(FDfile):
        curvenum += 1
        strainturn = strainturnlist[index];scaleturn = scaleturnlist[index];curvescale = curvescalelist[index]
        x,y,peak = MAT89LCSS(File,A,l0) 
        x_fit,y_fit= MAT24LCSS(x,y,yieldpoint=yieldpoint,Ymould_user=Ymould_user,Peak=peak,strainturn=strainturn,scaleturn=scaleturn,curvescale=curvescale,ratio=ratio,extend=extend,scaleextend=scaleextend,alignstrain =alignstrain,pointnum=pointnum,smoothflag=smooth)    
        fout.write('*DEFINE_CURVE_TITLE\nRate %.5f\t%s\n' %(pow(np.e,strain_rate[index]),File))
        fout.write('$     LCID      SIDR       SFA       SFO      OFFA      OFFO    DATTYP\n')
        fout.write('      %d         0    1.0000&scale        0.0000    0.0000\n' %(curvenum))
        for i in range(len(x_fit)):
            fout.write("%f,%f\n" %(x_fit[i],y_fit[i]))
    fout.write("*END\n")
    fout.close()
    return x_fit,y_fit,x,y
#    plt.show()

def CowperSymondsCurve(File,A,l0,Ymould_user,pointnum,ratelist,x_p,y_p):
   y_strain = []
   x_strain = []
   for index,value in enumerate(x):
       if value >= yieldpoint and (value > x[index-1] or y[index]>y[index-1]):
           x_strain.append(value - y[index]/Ymould_user)
           y_strain.append(y[index])
   plt.figure(4)
   plt.plot(x_strain,y_strain,'--')
   popt,pcov = optimize.curve_fit(CowperSymondsFunc,x_p,y_p,[0.001,0.001])
   c = popt[0];p = popt[1]
#    print "Cowper-Symonds Constants:\nc:%f\tp:%f\n" %(c,p)
   x_strain_fit = np.linspace(0,x_strain[-1],pointnum)
   for rate in ratelist:
       plt.figure(4)
       y_strain_fit = CowperSymondsFunc(x_strain_fit,c,p,rate=0.001)
       plt.plot(x_strain_fit,y_strain_fit)
   return x_strain_fit,y_strain_fit

    

def CurveKey1(x,y,strainrate_list,curvenum):
    # x,y = CowperSymondsCurve(FDfile[0],A,l0,Ymould_user,80,ratelist,x_p,y_p)
    fout = open("Curve.key",'w')
    fout.write('*KEYWORD\n')
    fout.write( "$%10s%10s%10s%10s%10s%10s%10s%10s\n" %('c1','c2','m','a','K','c3','c4','alpha'))
    fout.write( "$%10.4f%10.4f%10.4f%10.4f%10.4f%10.4f%10.4f%10.4f\n" %(c1,c2,m,a,K,c3,c4,alpha))
    fout.write('$ Created: ' + time.strftime("%d.%m.%Y %H:%M:%S") + '\n')
    fout.write("*DEFINE_TABLE\n%d\n" %(curvenum))
    for i in strainrate_list:
        fout.write("%f\n" %(i))
    for index,strainrate in enumerate(strainrate_list):
        res = [ x[index], y[index].tolist()]
        condition = "(res[0][i]<res[0][i+1] or res[1][i]>res[1][i+1])"
        x[index], y[index]= ConditionRemove(res,condition)
        curvenum += 1
        flag = 0 
        fout.write('*DEFINE_CURVE_TITLE\nRate %.5f\n' %(strainrate_list[index]))
        fout.write('$     LCID      SIDR       SFA       SFO      OFFA      OFFO    DATTYP\n')
        fout.write('      %d         0    1.0000    1.0000    0.0000    0.0000\n' %(curvenum))
        plt.figure(5)
        plt.plot(x[index],y[index])
        plt.grid('on')
        for i in range(len(x[index])):
            if x[index][i] > 0:
                if flag == 0 :
                    fout.write("%f,%f\n" %(0,y[index][i]))
                    flag = 1
                if flag != 0 :
                    fout.write("%f,%f\n" %(x[index][i],y[index][i]))
    fout.write("*END\n")
    fout.close()
    plt.savefig('curve')
    return
    
if __name__ == '__main__':
    Ymould_user = 1.5 #定义弹性模量
    curvenum = 2350 #key文件中曲线的编号起始编号
    pointnum = 80#
    T = float(<<T>>);
    s11 = float(<<s11>>); s12 = float(<<s12>>); s13 = float(<<s13>>); s14 = float(<<s14>>); s15 = float(<<s15>>)
    s21 = float(<<s21>>); s22 = float(<<s22>>); s23 = float(<<s23>>); s24 = float(<<s24>>); s25 = float(<<s25>>)
    a_list =[float(<<a1>>),float(<<a2>>)]
    strain = [0.2,0.4,0.6];
    stress_list=[[s11,s12,s13,s14,s15],[s21,s22,s23,s24,s25]]
    strainrate_list = [[1.0,0.1],[0.01,0.001]]
    T = [238.,358.]
    res_stress = []
    res_strain = []
    for (stress,strainrate,a_) in zip(stress_list,strainrate_list,a_list):
        print "stress:",stress
        print "strainrate",strainrate
        c1,c2 = DGSZ_c1c2(strain,stress)
        m = DGSZ_m(strainrate,[stress[0],stress[3]])
        alpha = DGSZ_alpha(T,[stress[0],stress[4]])
        K = DGSZ_K(stress[0],strain[0],strainrate[0],m,T[0],alpha,c1,c2)
        c3 = DGSZ_c3(strain[0],strainrate[0],m,T[0],alpha)
        c4 = DGSZ_c4(strainrate[0],m,alpha,T[0])
        a = DSGZ_a(a_)
        #
        print "c1\tc2\tm\ta\tK\tc3\tc4\talpha"
        print "%f \t %f \t %f \t %f \t %f \t %f \t %f \t %f" %(c1,c2,m,a,K,c3,c4,alpha)
        #
        strain_curve =np.linspace(0.0001,2.,pointnum)
        for index,sr in enumerate(strainrate):
            stress = DGSZ(strain_curve,sr,T[0],K,c1,c2,c3,c4,a,m,alpha)
            res_stress.append(stress)
            res_strain.append([strain_curve[i] - stress[i]/Ymould_user for i in range(pointnum)])
    for loop in range(10):
        for i in range(len(res_stress[0])):
            comp = [res_stress[j][i] for j in range(len(res_stress))]
            flag = [comp.index(x) for x, y in zip(comp, comp[1:]) if x<y]
            if flag != []:
                mod_index = flag[0]
                res_stress[mod_index][i] = res_stress[mod_index+1][i]+res_stress[mod_index][i]/10.
                res_strain[mod_index][i] = res_strain[mod_index+1][i]
    strainrate_output =strainrate_list[0]+strainrate_list[1]
    
    res_stress.reverse()
    strainrate_output.reverse()
    CurveKey1(res_strain,res_stress,strainrate_output,curvenum)
    print("N o r m a l") 