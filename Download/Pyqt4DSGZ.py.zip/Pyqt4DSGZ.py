# -*- coding: utf-8 -*-
import sys
import os
import random
import time
import numpy as np
import matplotlib
matplotlib.use("Qt5Agg")
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QApplication, QMainWindow, QMenu, QVBoxLayout, QSizePolicy, QMessageBox, QWidget
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from numpy import arange
import pandas as pd
import ControlCanvas


def FD2ESS(dis,force,L,A):
	EngStrain = dis/L
	EngStress = force/A
	return EngStrain,EngStress

def ESS2TSS(EngStrain,EngStress):
	TrueStrain =  np.log(1+EngStrain)
	TrueStress = EngStress*(1+EngStrain)
	return TrueStrain,TrueStress
	
def FindFile(start, name):
	#Find the files whose name string contains str(name), and the directory of files
	isFlag = 0
	lenname = len(name)
	if  '*' in name:
		name = name.strip('*')
		isFlag =1
		lenname = len(name)-1
	relpath =[]
	files_set = []
	dirs = []
	dirs_set = []

	if isFlag == 0:
		for relpath, dirs, files in os.walk(start):
			for i in files:
				if name == i[-lenname:]:
					full_path = os.path.join(start, relpath, i)
					files_set.append(os.path.normpath(os.path.abspath(full_path)))
					dirs_set.append(os.path.join(start, relpath))
						
	elif isFlag == 1:
		for relpath, dirs, files in os.walk(start):
			for i in files:
				if os.path.splitext(i)[-1] == name:
					full_path = os.path.join(start, relpath, i)
					files_set.append(os.path.normpath(os.path.abspath(full_path)))
					dirs_set.append(os.path.join(start, relpath))
	
	dirs_set = list(set(dirs_set))
	return files_set,dirs_set



class Ui_MainWindow(object):	
	def setupUi(self, MainWindow):
		MainWindow.setObjectName("MainWindow")
		self.screen = QtWidgets.QDesktopWidget().screenGeometry()
		MainWindow.setGeometry(10, 50, self.screen.width()/4,self.screen.height()/4)
		# MainWindow.resize(self.screen.width()/4,self.screen.height()/4)
		# MainWindow.showMaximized()
		self.centralWidget = QtWidgets.QWidget(MainWindow)
		self.centralWidget.setObjectName("centralWidget")
		MainWindow.setCentralWidget(self.centralWidget)
		self.testing = [0,0]
####################################################################################
		#QGridLayout
		self.gridLayout = QtWidgets.QGridLayout(self.centralWidget)
		self.gridLayout.setSpacing(2)
		self.gridLayout.setObjectName("gridLayout")
		#splitter
		self.splitter = QtWidgets.QSplitter(orientation=QtCore.Qt.Horizontal)
		self.gridLayout.addWidget(self.splitter,1,0,8,0)
		self.splitter.setSizes([self.splitter.size().height() * 0.8, self.splitter.size().height() * 0.2])
		# Canvas
		self.main_widget = QWidget()
		self.dc = ControlCanvas.MyControlMplCanvas(self.main_widget, width=5, height=4, dpi=100)
		self.splitter.addWidget(self.dc)
		# self.gridLayout.addWidget(self.dc,rowspan=-1)
		#
		#QVBoxLayout
		self.verticallayout = QtWidgets.QVBoxLayout()
		# self.verticallayout.setContentsMargins(11, 11, 11, 11)
		self.verticallayout.setSpacing(6)
		self.verticallayout.setObjectName("verticallayout")
		self.gridLayout.addLayout(self.verticallayout, 0, 1)
		#
		self.lb = []
		self.hs = []
		self.sp = []
		self.echoGroup =  QtWidgets.QGroupBox('Echo')
		self.echoLayout = QtWidgets.QGridLayout()
		self.echoGroup.setLayout(self.echoLayout)
		sp_inital_value = [7.8e-3,1.22,1.078,31,10.,0.1,1.0,1.52]
		sp_range = [[0.00001,9999],[-500.,500.],[-500.,500.],[0.,500.],[0.,1000.],[0.,100.],[0.,9999.],[0.,100.]]
		lb_name = ['K-scale','C1-curve trend','C2-curve trend','C3--Yiled strain','C4-init strain softening','m-strain rate','alpha','a-init']
	
		for i in range(8):
			self.lb.append(i);self.hs.append(i);self.sp.append(i)
			self.lb[i] = QtWidgets.QLabel(lb_name[i])
			self.echoLayout.addWidget(self.lb[i],i+1,0)
			self.hs[i] = QtWidgets.QSlider(self.centralWidget)
			self.hs[i].setOrientation(QtCore.Qt.Horizontal)
			self.hs[i].setRange(sp_range[i][0],sp_range[i][1])
			self.echoLayout.addWidget(self.hs[i],i+1,2)

			self.sp[i] = QtWidgets.QDoubleSpinBox()
			self.sp[i].setDecimals(5)

			# self.sp[i].valueFromText('0.2')
			self.sp[i].setValue(sp_inital_value[i])
			self.sp[i].setSingleStep(0.01*sp_inital_value[i]) 
			self.sp[i].setRange(sp_range[i][0],sp_range[i][1])
			self.echoLayout.addWidget(self.sp[i],i+1,1)
			self.hs[i].valueChanged.connect(self.sp[i].setValue)
			self.sp[i].valueChanged.connect(self.hs[i].setValue)
			self.hs[i].sliderReleased.connect(lambda: self.dc.update_figure(pars=self.DSGZ_args()))
			self.sp[i].valueChanged.connect(lambda: self.dc.update_figure(pars=self.DSGZ_args()))
		self.splitter.addWidget(self.echoGroup)
		#
		self.testingGroup =  QtWidgets.QGroupBox('Testing')
		self.testingLayout = QtWidgets.QGridLayout()
		self.testingGroup.setLayout(self.testingLayout)
		self.gridLayout.addWidget(self.testingGroup,0,0)
		#
		self.cb1 = QtWidgets.QCheckBox('Clear')
		self.testingLayout.addWidget(self.cb1,0,2)
		#LineEdit
		self.e1 = QtWidgets.QLineEdit()
		self.e1.setMaxLength(80)
		self.e1.setAlignment(QtCore.Qt.AlignRight)
		self.testingLayout.addWidget(self.e1,0,0)
		##QFileDir
		self.btn2 = QtWidgets.QPushButton("打开目标文件")
		self.testingLayout.addWidget(self.btn2,0,1)
		self.btn2.clicked.connect(self.filedirgetfile)
		#Group2_Spin
		self.sp_testing = QtWidgets.QDoubleSpinBox()
		self.echoLayout.addWidget(self.sp_testing,0,3)
		#
		#Group2_Qlist
		#QCombox
		self.comboLayout = QtWidgets.QGridLayout()
		self.combobox2 = QtWidgets.QComboBox(minimumWidth=200)
		self.comboLayout.addWidget(QtWidgets.QLabel("111"))
		self.comboLayout.addWidget(self.combobox2)
		self.comboLayout.addItem(QtWidgets.QSpacerItem(20, 20, QtWidgets.QSizePolicy.Expanding,QtWidgets.QSizePolicy.Minimum))
		items_list=["C","C++","Java","Python","JavaScript","C#","Swift","go","Ruby","Lua","PHP"]
		datas_list=[1972,1983,1995,1991,1992,2000,2014,2009,1995,1993,1995]
		for i in range(len(items_list)):
			self.combobox2.addItem(items_list[i],datas_list[i])
		self.combobox2.setCurrentIndex(-1)
		self.combobox2.activated.connect(self.on_combobox2_Activate)
		self.echoLayout.addWidget(self.combobox2,0,0)
		##
	def on_combobox2_Activate(self, index):
		print(self.combobox2.currentText())
		print(self.combobox2.currentData())
		#
		#Define call function
	def itemclicked(self,item):
		print (item.text())
		#
	def filedirgetfile(self):
		# try:
			# self.filedir,_ = QtWidgets.QFileDialog.getOpenFileName(caption='Open',directory="D:\\",filter="CSV files(*.txt *.csv)")
			self.testing = []
			csv_files = FindFile(self.e1.text(),'.csv')[0]
			for file in csv_files:
				fd = pd.read_csv(file)
				EES = FD2ESS(fd.Disp,fd.Force,10.,12.)
				# self.testing.append((EES[0],EES[1]))
				self.testing.append(ESS2TSS(EES[0],EES[1]))
			print (len(self.testing))
			return self.testing
		# except:
			# pass
	#
	def DSGZ_args(self):
		self.DSGZ_Args = [self.sp[i].value() for i in range(8)]
		# self.dc.update_figure(self.DSGZ_Args)
		return self.DSGZ_Args,self.testing,self.cb1.checkState()
####################################################################################
if __name__ == "__main__":
	app = QtWidgets.QApplication(sys.argv)
	ex = Ui_MainWindow()
	w = QtWidgets.QMainWindow()
	ex.setupUi(w)
	w.show()
	sys.exit(app.exec_())
####################################################################################