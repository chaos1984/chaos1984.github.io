# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

#Sample information
l = 105.702 #Gauge length
h = 3   #Thickness
tb = 10.#Width
A = h*tb
A = np.pi*5*5
E = 188.8019

k = E*A/l
force = 23.693
print "Stiffness:",k
eps = force/(E*A-force)
sigma = eps*E
dist = l*eps
print "force: %f kN;strain:%f;stress:%f GPa;Distance:%f mm" %(force,eps,sigma,dist)
