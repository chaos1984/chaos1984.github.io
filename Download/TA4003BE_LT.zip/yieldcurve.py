#CREATE YIELD CURVE WITH MODIFIED HOCKETT-SHERBY
#David Koch, Christian Ilg, Pedro Roehl
#PYTHON 3.5

import sys
import csv
import math
import time
import matplotlib.pyplot as plt
import numpy as np
s0 = float('<<s0>>')
a = [float('<<a0>>'),float('<<a1>>'),float('<<a2>>')]
c0 = float('<<c0>>')
c1 = float('<<c1>>')

def getYieldCurve(s):
	yieldcurve_eps = []
	yieldcurve_sig = []
	SamplePoints = 300
	stepsize = 2.0 / (SamplePoints-1)
	for i in range(SamplePoints):
		val = i*stepsize
		yieldcurve_eps.append(val)
		yieldcurve_sig.append(s+c0*pow(val,c1))
	return yieldcurve_eps, yieldcurve_sig

	
	

strain_rate = [-6.907,-4.605,-2.302,0]
curve_num = 2350
ycfile = 'Curve.key'
f_yc = open(ycfile, 'w')
f_yc.write('*KEYWORD\n')
f_yc.write('$ Created: ' + time.strftime("%d.%m.%Y %H:%M:%S") + '\n')
f_yc.write("*DEFINE_TABLE\n%d\n" %(curve_num))
for i in strain_rate:
	f_yc.write("%f\n" %(i))
for i in range(len(strain_rate)):
	curve_num += 1
	s = s0 + sum(a[:i])
	yieldcurve_eps, yieldcurve_sig = getYieldCurve(s)
	plt.plot(yieldcurve_eps,yieldcurve_sig)
	f_yc.write('*DEFINE_CURVE_TITLE\n%f\n' %(i))
	f_yc.write('$     LCID      SIDR       SFA       SFO      OFFA      OFFO    DATTYP\n')
	f_yc.write('      %d         0    1.0000    1.0000    0.0000    0.0000\n' %(curve_num))
	f_yc.write('%20.8e %19.8e\n' %(0.0,  s))
	for i in range(len(yieldcurve_eps)):
		if yieldcurve_sig[i] > s:
			f_yc.write('%20.8e %19.8e\n' %(yieldcurve_eps[i],  yieldcurve_sig[i]))
f_yc.close()
plt.savefig('curve.png')
for i in range(len(strain_rate)):
	filename = 'Curve_' + str(pow(10,i+1))+'.key'
	fout = open(filename,'w')
	curve_num = 2350
	for line in open('Curve.key'):
		if ("    1.0000    1.0000    0.0000    0.0000" in line):
			curve_num += 1
			fout.write('      %d         0    1.0000%10.2f0.0000    0.0000\n' %(curve_num , pow(10,i+1)))
		else:
			fout.write(line)
	fout.close()
print "N o r m a l"
