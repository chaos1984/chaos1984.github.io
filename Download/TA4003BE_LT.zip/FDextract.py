# -*- coding: utf-8 -*-
"""
Spyder Editor
This is a temporary script file.
"""

fileinput = "test100_.txt"
fout = open("test100.txt",'w')
no = 80

finp = open(fileinput,'r')
n = round(len(finp.readlines())/no)
i = 0
for line in open(fileinput,'r'):
    i += 1
    if i%n == 0:
        fout.write(line)
fout.close()